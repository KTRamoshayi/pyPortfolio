import copy
import random
# Consider using the modules imported above.

class Hat:

    def __init__(self, **kwargs):
        self.contents = list()

        for attr in kwargs.keys():
            self.__dict__[attr] = kwargs[attr]

        for x, y in kwargs.items():
            for z in range(int(y)):
                 self.contents.append(x)
        
    # For each expiriment, temp list is created and used to withdraw and remove ball.
    def draw(self, num):
        temp_balls = list(self.contents)
        balls = list()

        for i in range(num):
            x = random.choice(temp_balls)
            balls.append(x)
            temp_balls.remove(x)

        return balls

def experiment(hat, expected_balls, num_balls_drawn, num_experiments):
    withdraw_count = 0

    for i in range(num_experiments):
        withdraw = hat.draw(num_balls_drawn)

        fail = False
        for x, y in expected_balls.items():        
            if withdraw.count(x) < y:
                fail = True
        
        if not fail:
            withdraw_count += 1
    
    return withdraw_count / num_experiments
    