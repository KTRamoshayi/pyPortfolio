#Did it myself, run tests manually, test_module never seems to give expected results though when running tests manually, everything is okay...

def arithmetic_arranger(problems, exit=False):
    ap = str()
    sp = []

    allowed_opperations = ["+", "-"]

    if exit:
        if len(problems) > 5:
            return "Error: Too many problems."

        for i in problems:
            if i.split()[1] not in allowed_opperations:
                return "Error: Operator must be '+' or '-'."

            elif len(i.split()) == 3:
                try:
                    x = int(i.split()[0])
                    if x > 9999:
                        return "Error: Numbers cannot be more than four digits."

                    y = int(i.split()[2])
                    if y > 9999:
                        return "Error: Numbers cannot be more than four digits."
                        
                except ValueError:
                    return "Error: Numbers must only contain digits."

            sp.append([
                    i.split()[0],
                    i.split()[1],
                    i.split()[2],
                    eval(i)
                ])


        spaces = "    "
        first_row_as_list = []
        second_row_as_list = []
        third_row_as_list = []
        last_row_as_list = []

        for ls in sp:
            length_of_last_row = len(str(ls[-1])) + 2
            first_row = " " * (length_of_last_row - len(str(ls[0]))) + str(ls[0])
            second_row = str(ls[1]) + " " * (length_of_last_row - 1 - len(str(ls[2]))) + str(ls[2])
            third_row = "-" * length_of_last_row
            last_row = " " * 2 + str(ls[3])


            first_row_as_list.append(first_row)
            second_row_as_list.append(second_row)
            third_row_as_list.append(third_row)
            last_row_as_list.append(last_row)

        first_row_as_string = spaces.join(first_row_as_list)
        second_row_as_string = spaces.join(second_row_as_list)
        third_row_as_string = spaces.join(third_row_as_list)
        last_row_as_string = spaces.join(last_row_as_list)

        ap = "\n".join([
            first_row_as_string,
            second_row_as_string,
            third_row_as_string,
            last_row_as_string
        ])

    arranged_problems = ap

    return arranged_problems