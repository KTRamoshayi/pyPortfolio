class Rectangle:

    def __init__(self, width, height):
        self.width = width
        self.height = height


    def __str__(self):
        return "Rectangle(width=" + str(self.width) + ", height=" + str(self.height) + ")"


    def set_width(self, width):
        self.width = width
        

    def set_height(self, height):
        self.height = height


    def get_area(self):
        return self.width * self.height
    

    def get_perimeter(self):
        return self.width * 2 + self.height * 2

    
    def get_diagonal(self):
        return (self.width ** 2 + self.height ** 2) ** .5


    def get_picture(self):
        pic_string = "Too big for picture."

        if self.width > 50:
            return pic_string
        
        if self.height > 50:
            return pic_string
        
        else:
            for i in range(self.height):
                pic_string = "*" * self.width + "\n"        
        return pic_string


    def get_amount_inside(self, shape):
        fiw = int(self.width / shape.width)
        fih = int(self.height / shape.height)

        return fih * fiw

        

class Square(Rectangle):
    
    def __init__(self, side):
        self.width = side
        self.height = side
        self.side = side


    def __str__(self):
        return "Square(side=" + str(self.side) + ")"


    def set_side(self, side):
        self.width = side
        self.height = side
        self.side = side


    def set_width(self, width):
        self.set_side(width)


    def set_height(self, height):
        self.set_side(height)