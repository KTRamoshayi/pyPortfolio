class Category:

    def __init__(self, name):
        self.name = name
        self.ledger = list()
    

    def __str__(self):
        slip = ""
        length_of_name = len(self.name)
        stars = (30 - length_of_name) // 2
        slip += "*" * stars
        slip += self.name
        slip += "*" * stars

        if len(slip) == 31:
            slip = slip[:-1]

        slip += "\n"

        for i in self.ledger:
            slip += i["description"][:23]
            slip += " " * (30 - len(i["description"][:23]) - len(str(format(i["amount"] + 0.00001, ".2f"))))
            slip += str(format(i["amount"] + 0.000001, ".2f"))
            slip += "\n"
        
        slip += "Total: " + str(float(self.get_balance()))

        return(slip)

    def get_balance(self):
        amount = 0
        for i in self.ledger:
            amount += i["amount"]
        return amount

 
    def check_funds(self, amount):
        if amount > self.get_balance():
            return False
        else:
            return True



    def deposit(self, amount, description=""):
        self.ledger.append({
            "amount" : amount,
            "description": description
        })
    

    def withdraw(self, amount, description=""):
        if self.check_funds(amount):
            self.ledger.append({
                "amount" : (amount * -1),
                "description": description
            })
            return True

        else:
            return False

    
    def transfer(self, amount, category):
        if self.check_funds(amount):
            self.ledger.append({
                "amount" : (amount * -1),
                "description": "Transfer to " + category.name
            })

            category.deposit(amount, "Transfer from " + self.name)
            return True

        else:
            return False
    


def create_spend_chart(categories):
    space = "    "
    index = {
        10: "100|",
        9 : " 90|",
        8 : " 80|",
        7 : " 70|",
        6 : " 60|",
        5 : " 50|",
        4 : " 40|",
        3 : " 30|",
        2 : " 20|",
        1 : " 10|",
        0 : "  0|"
    }
    ts = 0
    spendings = {}
    percentages = {}

    # Calculate percentages
    for i in categories:
        amount = 0
        for x in i.ledger:
            if x["amount"] < 0:
                amount -= x["amount"]
        
        spendings[i.name] = amount
        ts += amount

    # Graph data as bars
    for i in categories:
        percentages[i.name] = int(spendings[i.name] / ts * 100  // 10)
        for x in range(0, 11):
            if x > percentages[i.name]:
                index[x] += "   "
            else:
                index[x] += " o "

    # Graph data to bar chart
    chart_string = "Percentage spent by category \n"

    for i in range(0, 11)[::-1]:
        chart_string += index[i]
        chart_string += " \n"
    
    chart_string += space

    # Determine longest budget name and add width to table for each category
    name_length = 0
    for i in categories:
        chart_string += "-" * 3
        if len(i.name) > name_length:
            name_length = len(i.name)

    chart_string += "- "

    # Register length of budget to budget_title_index
    budget_title_index = {}
    for i in range(0, name_length):
        budget_title_index[i] = space

    # Covert budget name to list with the length of the longest name_length
    for i in categories:
        name_as_list = list(i.name)
        for x in range(name_length):
            if x < len(name_as_list):
                budget_title_index[x] += " " + name_as_list[x] + " "
            else:
                budget_title_index[x] += "   "
    

    # Add each index of budget_title_index to chart
    for x, y in budget_title_index.items():
        chart_string += "\n" + y + "  "


    return chart_string