def add_time(start, duration, day=None):
    starting_time, starting_period = start.split()
    starting_hour, starting_min = starting_time.split(":")
    elapsing_hour, elapsing_min = duration.split()[0].split(":")

    new_hour = int(starting_hour) + int(elapsing_hour)
    new_mins = int(starting_min) + int(elapsing_min)

    src_apm = {
        1 : "AM",
        2 : "PM"
    }

    src_day = {
        0 : "sunday",
        1 : "monday",
        2 : "tuesday",
        3 : "wednesday",
        4 : "thursday",
        5 : "friday",
        6 : "saturday",
        7 : "sunday"
    }


    if day != None:
        for key, value in src_day.items():
            if value == day.lower():
                starting_day = key
        

    if new_mins > 60:
        new_hour += 1
        new_mins -= 60
    
    if new_hour > 12:
        if starting_period == "AM":
            apm = 1
        else:
            apm = 2

        temp_apm, new_hour = divmod(new_hour, 12)

        apm += temp_apm

        if apm % 2 == 0:
            apm = 2
        else:
            apm = 1
        
        current_time = str(new_hour).zfill(2) + ":" + str(new_mins).zfill(2) + " " + str(src_apm[apm])

        if starting_period == "PM":
            if day != None:
                temp_day, new_day_key = divmod(starting_day+((temp_apm+1)/2), 7)
                current_time += ", " + str(src_day[int(new_day_key)]).title()

            if temp_apm <= 2 and temp_apm > 0:
                current_time += " (next day)"
            else:
                current_time += " " + str(int((temp_apm+1)/2)) + " days later"

                
        
        if starting_period == "AM":
            if day != None:
                temp_day, new_day_key = divmod(starting_day+(temp_apm/2), 7)
                current_time += ", " + str(src_day[int(new_day_key)]).title()

            if temp_apm == 2:
                current_time += " (next day)"
            if temp_apm > 2:
                current_time += " " + str(int(temp_apm/2)) + " days later"


    else:
        current_time =  str(new_hour).zfill(2) + ":" + str(new_mins).zfill(2) + " " + starting_period
        if day != None:
            for key, value in src_day.items():
                if value == day.lower():
                    starting_day = key
            current_time += ", " + str(src_day[starting_day]).title()
        

               



    new_time = current_time

    return new_time